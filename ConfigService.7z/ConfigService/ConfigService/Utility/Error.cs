﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace ConfigService.Utility
{
    public class Error
    {
        public static void Log(Exception ex)
        {
            try
            {
                string tempFolder = Path.GetTempPath();
                //string tempFolder = Directory.GetCurrentDirectory();
                string mainFolder = "PDM_LOG";
                string filePrefix = DateTime.Now.ToString("yyyyMMdd");
                string fileName = filePrefix +"_"+ "LogFile.txt";

                string directoryPath = Path.Combine(tempFolder, mainFolder, fileName);
                string fullPath = Path.Combine(tempFolder, mainFolder, fileName);

                System.IO.Directory.CreateDirectory(directoryPath);
                using (StreamWriter streamWriter = File.AppendText(fullPath))
                {
                    string strDateTime = 
                        DateTime.Now.ToString(
                            "MM/dd/yyyy HH:mm:ss.fff",
                            CultureInfo.InvariantCulture);

                    streamWriter.WriteLine("[{0}]: {1}", strDateTime, ex);
                }
            }
            catch(Exception exception)
            {
                Debug.WriteLine(exception);
            }
        }
    }
}
