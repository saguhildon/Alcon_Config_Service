﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigService.Models
{
    public class JobSite
    {
        public int? id { get; set; }
        public string jobsitename { get; set; }
        public int? countryid { get; set; }

        [NotMapped]
        public string address { get; set; }
        [NotMapped]
        public string contactnumber { get; set; }
       
    }
}
