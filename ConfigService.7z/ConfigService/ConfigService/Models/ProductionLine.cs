﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigService.Models
{
    public class ProductionLine
    {
        public int? id { get; set; }
        public string productionlinename { get; set; }
        
    }
}
