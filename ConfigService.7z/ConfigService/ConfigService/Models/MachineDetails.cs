﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigService.Models
{
    public class MachineDetails
    {
        public int? id { get; set; }
        public string substationcode { get; set; }
        public string substationname { get; set; }        
        public double? positionx { get; set; }
        public double? positiony { get; set; }
        public double? positionz { get; set; }
        public double? rotationx { get; set; }
        public double? rotationy { get; set; }
        public double? rotationz { get; set; }

        public double? geometrywidth { get; set; }
        public double? geometryheight { get; set; }
        public double? geometrydepth { get; set; }
        public string? imagefile { get; set; }
        public string substationstatuscode { get; set; }

    }
}
