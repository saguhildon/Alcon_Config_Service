﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ConfigService.Models
{
    [Table("config_country")]
    public class Country
    {
        [Key]
        [Column("id", Order = 1)]
        public int? id { get; set; }

        [Column("countryname", Order = 2)]
        public string countryname { get; set; }
    }
}
