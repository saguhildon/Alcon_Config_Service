﻿using ConfigService.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigService.DBContext
{
    public class ConfigContext : DbContext
    {
        public ConfigContext()
        {
        }
        public ConfigContext(DbContextOptions<ConfigContext> options) : base(options) { }
        public DbSet<Country> Country { get; set; }
        public DbSet<JobSite> JobSite { get; set; }
        public DbSet<MachineDetails> MachineDetails { get; set; }
        public DbSet<ProductionLine> ProductionLine { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("public");
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Country>(entity => {
                entity.ToTable("conf_country", "public");
                entity.Property(e => e.id).HasColumnName("id").HasDefaultValueSql("nextval('public.conf_Country_id_seq'::regclass)");
                entity.Property(e => e.countryname).HasColumnName("countryname");
            });

            //modelBuilder.Entity<Country>().HasNoKey();
            modelBuilder.Entity<JobSite>().HasNoKey();
            modelBuilder.Entity<MachineDetails>(entity => { 
                entity.HasNoKey();
            });
        }


    }
}
