﻿using ConfigService.DBContext;
using ConfigService.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConfigController : Controller
    {
        
        private readonly ConfigContext _db;
        public ConfigController(ConfigContext db)
        {
            _db = db;
        }

        [HttpGet("GetCountry")]
        public async Task<ActionResult<IEnumerable<Country>>> GetCountry()
        {
            return await _db.Country.ToListAsync();
        }

        [HttpGet("GetProductionLine")]
        public async Task<ActionResult<IEnumerable<ProductionLine>>> GetProductionLine()
        {
            string StoredProc = "SELECT *  FROM public.conf_productionline";

            //return await _context.output.ToListAsync();  
            return await _db.ProductionLine.FromSqlRaw(StoredProc).ToListAsync();
        }

        [HttpGet("GetMachineDetails")]
        public async Task<ActionResult<IEnumerable<MachineDetails>>> GetMachineDetails(string productionlineName = null)
        {
            //string StoredProc = "SELECT id, machinecode, machinename, jobsiteid, positionx, positionz,  rotationy FROM public.conf_machinedetails;";

            //return await _context.output.ToListAsync(); 
            var parameters = new object[] {
                new NpgsqlParameter("_productionline_name", NpgsqlDbType.Varchar) { Value = (object)productionlineName ?? DBNull.Value }
            };

            return await _db.MachineDetails.FromSqlRaw($"SELECT * FROM get_station_details(@_productionline_name)", parameters).ToListAsync();
        }

    }
}
